// import React, { useEffect, useState } from "react";
// import RegistrationForm from "./Component/RegistrationForm";
import "./App.css";
import Registration from "./component/Registration";

// const API = "https://jsonplaceholder.typicode.com/users"

const App = () => {
//   const [users, setUsers] = useState([]);
//   useEffect(()=>{
// const userData = async () =>
// {
//   try{
// const response = await fetch("https://jsonplaceholder.typicode.com/users");
// const data = await response.json();
// console.log(data);
// setUsers(data);

//   }catch(e){console.log(e)}
// }
// userData();

//   },[])


//   // Render the user table
  return (

    <Registration/>

    // <div>
    //   <h1>User List</h1>
    //   <table border="1" cellPadding="10" cellSpacing="0" style={{ width: "100%" }}>
    //     <thead>
    //       <tr>
    //         <th>ID</th>
    //         <th>Name</th>
    //         <th>Username</th>
    //         <th>Email</th>
    //         <th>Address</th>
    //         <th>Phone</th>
    //         <th>Website</th>
    //         <th>Company</th>
    //       </tr>
    //     </thead>
    //     <tbody>
    //       {/* <RegistrationForm></RegistrationForm> */}
    //     {/* {users.map((user) => (
    //         <tr key={user.id}>
    //           <td>{user.id}</td>
    //           <td>{user.name}</td>
    //           <td>{user.username}</td>
    //           <td>{user.email}</td>
    //           <td>
    //             {user.address?.street}, {user.address?.suite}, {user.address?.city}, {user.address?.zipcode}
    //           </td>
    //           <td>{user.phone}</td>
    //           <td>{user.website}</td>
    //           <td>{user.company?.name}</td>
    //         </tr>
    //       // ))} */}
    //     </tbody>
    //   </table> 
      

    // </div>
  );
};

export default App;


