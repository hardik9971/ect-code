import React, { useState } from 'react';

const Registration = () => {
  const [user, setUser] = useState('');

  const handleChange = (e) => {
    setUser(e.target.value);
    console.log(e.target.value);
  };

  const handleSubmit=()=>{
    console.log("Submitted",user)
  }

  return (
    <div>
      <h1>Registration Form</h1>
      <label>Username</label>
      <input
        type="text"
        name="username"
        value={user}
        onChange={handleChange} 
      />
      <button onClick={handleSubmit}>SUBMIT</button>
    </div>
  );
};

export default Registration;
